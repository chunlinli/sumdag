# Author: Rachel Zilinskas #
# Date: 05/24/2021 #
# Updated - 4/18/2022 to incorporate new filtering and choosing p-value threshold and method for V estimation #
# Updated 5/24/2022 to incorporate new MR analysis results
# Purpose: To create a shiny app to concisely display the results of my initial estimation of a protein 
# DAG using summary statistics from Fokersen et al. 

# Setting working directory - comment out when ready to publish 
setwd("/Users/Rachel/Documents/statGen/GRN/DAG/DAG_WithSS/ssIntDag_ShinyApp_Paper/")

# Sourcing helper functions
#source("helper.R")
#source("jointBetasHelper.R")
#source("DAGhelper.R")

# loading required packages 
library(shiny)
library(stringr)
library(dagitty)
library(pcalg)
library(ggdag)
library(ggplot2)
library(stringr)
library(tidyr)
library(dplyr)
library(gt)
library(BiocManager)
options(repos = BiocManager::repositories())

# Loading other TLP results

# Definining the ancestry relationships to choose from in the graph 
rel_choices = c("descendants", "ancestors", "children", "neighbors", "spouses", "adjacent nodes", "markov blanket")

# Reading in a DAG to have access to the column names to choose from in the graph 
U_MR <- as.matrix(read.table("p_value_mr.txt"))
U.TLP = as.matrix(read.table("U_TLP.txt"))
p_value = as.matrix(read.table("p_value.txt"))
p_value_mr = as.matrix(read.table("p_value_mr.txt"))

# Define UI for application
ui <- fluidPage(
  tabsetPanel(
    tabPanel("Real Data Results - TLP Regression",
             sidebarLayout(
               sidebarPanel(h3("To test the links in the DAG, we can conduct a Wald Test"),
                            textOutput("num_links_tlp"),
                            textInput("wald_p_thresh_tlp", "P-value threshold", value = 0.05) 
               ),
               mainPanel(plotOutput("dag_wald_plot_tlp"))
             )
    ),


    tabPanel("MR Results",
             sidebarLayout(
               sidebarPanel(h3("Visualizing the MR Results with AF as a node in the DAG"),
                            textInput("mr_p_thresh", "P-value threshold", value = 0.05),
                            selectInput("graph_prot", "Select a node", choices = colnames(U_MR), selected = "AD"),
                            h4("We can further subset the graphs to visualize the estimated relationships in the DAG"),
                            selectInput("relationship", "Select an ancestral relationship", choices = rel_choices, selected = "adjacent nodes")
               ),
               
               mainPanel(plotOutput("dag_plot_mr")))
    )
  )
  )

# Define server logic required to create output
server <- function(input, output) {
  # Making DAG plots using functions in helper file
  output$dag_wald_plot <- renderPlot({dag_wald_graph(input$wald_test, as.numeric(input$wald_p_thresh), input$v_est)})
  output$dag_wald_plot_tlp <- renderPlot({dag_wald_graph_tlp(U.TLP, p_value, input$wald_p_thresh_tlp)})
  output$num_links <- renderText({num_dag_links(input$v_est)})
  output$num_links_tlp <- renderText({num_dag_links_tlp(U.TLP)})
  output$dag_plot_mr <- renderPlot({dag_graph(input$graph_prot, input$relationship, input$mr_p_thresh)})
}

# Run the application 
shinyApp(ui = ui, server = server)